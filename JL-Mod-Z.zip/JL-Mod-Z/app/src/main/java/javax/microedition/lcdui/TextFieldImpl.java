/*
 * Copyright 2012 Kulikov Dmitriy
 * Copyright 2019 Nikita Shakarun
 * Copyright 2021-2026 Yury Kharchenko
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package javax.microedition.lcdui;

import static android.text.InputType.TYPE_CLASS_NUMBER;
import static android.text.InputType.TYPE_CLASS_PHONE;
import static android.text.InputType.TYPE_CLASS_TEXT;
import static android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL;
import static android.text.InputType.TYPE_NUMBER_FLAG_SIGNED;
import static android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
import static android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS;
import static android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
import static android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
import static android.text.InputType.TYPE_TEXT_VARIATION_URI;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.widget.EditText;

import androidx.appcompat.widget.AppCompatEditText;

import javax.microedition.lcdui.event.SimpleEvent;

class TextFieldImpl {
	private EditText textview;

	private String text;
	private int maxSize;
	private int constraints;

	private final SimpleEvent msgSetText = new SimpleEvent() {
		@Override
		public void process() {
			EditText editText = textview;
			if (editText != null) {
				editText.setText(text);
			}
		}
	};

	void setString(String text) {
		if (text != null && text.length() > maxSize) {
			throw new IllegalArgumentException("text length exceeds max size");
		}

		if (text != null) {
			this.text = text;
		} else {
			this.text = "";
		}

		if (textview != null) {
			ViewHandler.postEvent(msgSetText);
		}
	}

	void insert(String src, int pos) {
		String tmp = new StringBuilder(text).insert(pos, src).toString();
		setString(tmp);
	}

	String getString() {
		return text;
	}

	int size() {
		return text.length();
	}

	int setMaxSize(int maxSize) {
		if (maxSize <= 0) {
			throw new IllegalArgumentException("max size must be > 0");
		}

		this.maxSize = maxSize;

		if (textview != null) {
			textview.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxSize)});
		}

		return maxSize;
	}

	int getMaxSize() {
		return maxSize;
	}

	void setConstraints(int constraints) {
		this.constraints = constraints;

		if (textview != null) {
			int inputType = switch (constraints & TextField.CONSTRAINT_MASK) {
				case TextField.EMAILADDR -> TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
				case TextField.NUMERIC -> TYPE_CLASS_NUMBER | TYPE_NUMBER_FLAG_SIGNED;
				case TextField.PHONENUMBER -> TYPE_CLASS_PHONE;
				case TextField.URL -> TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_URI;
				case TextField.DECIMAL -> TYPE_CLASS_NUMBER | TYPE_NUMBER_FLAG_SIGNED | TYPE_NUMBER_FLAG_DECIMAL;
				default -> TYPE_CLASS_TEXT;
			};


			if ((constraints & TextField.NON_PREDICTIVE) != 0 ||
					(constraints & TextField.SENSITIVE) != 0 ||
					(constraints & TextField.PASSWORD) != 0) {
				inputType |= TYPE_TEXT_FLAG_NO_SUGGESTIONS;
			}

			if ((constraints & TextField.INITIAL_CAPS_WORD) != 0) {
				inputType |= TYPE_TEXT_FLAG_CAP_WORDS;
			}

			if ((constraints & TextField.INITIAL_CAPS_SENTENCE) != 0) {
				inputType |= TYPE_TEXT_FLAG_CAP_SENTENCES;
			}

			textview.setInputType(inputType);
			textview.setSingleLine(true);
			textview.setMaxLines(50);
			textview.setHorizontallyScrolling(false);
			textview.setEnabled((constraints & TextField.UNEDITABLE) == 0);

			if ((constraints & TextField.PASSWORD) != 0) {
				textview.setTransformationMethod(new PasswordTransformationMethod());
			}
		}
	}

	int getConstraints() {
		return constraints;
	}

	int getChars(char[] data) {
		text.getChars(0, text.length(), data, 0);
		return text.length();
	}

	int getCaretPosition() {
		if (textview != null) {
			return textview.getSelectionEnd();
		} else {
			return 0;
		}
	}

	void delete(int offset, int length) {
		String tmp = new StringBuilder(text).delete(offset, offset + length).toString();
		setString(tmp);
	}

	EditText getView(Context context, Item item) {
		if (textview == null) {
			textview = new AppCompatEditText(context);

			setMaxSize(maxSize);
			setConstraints(constraints);
			textview.setText(text);

			textview.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
				}

				@Override
				public void afterTextChanged(Editable s) {
					text = s.toString();
					if (item != null) {
						item.postStateChanged();
					}
				}
			});
		}
		return textview;
	}

	void clearScreenView() {
		textview = null;
	}
}
